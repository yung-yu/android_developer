package ${PACKAGE_NAME};

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

#parse("File Header.java")
public class ${NAME} extends Fragment {
    private final static String TAG = "${NAME}";
    
	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(TAG,"onCreate");
	}

	@Nullable
	@Override
	public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.i(TAG,"onCreateView");
		return inflater.inflate(R.layout.fragment, null);
	}

	@Override
	public void onViewCreated(@Nullable View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		Log.i(TAG,"onViewCreated");
	}


	@Override
	public void onStart() {
		super.onStart();
        Log.i(TAG,"onStart");
	}

	@Override
	public void onResume() {
		super.onResume();
        Log.i(TAG,"onResume");
	}

	@Override
	public void onPause() {
		super.onPause();
		Log.i(TAG,"onPause");
	}

	@Override
	public void onStop() {
		super.onStop();
		Log.i(TAG,"onStop");
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
        Log.i(TAG,"onDestroyView");
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		Log.i(TAG,"onDestroy");
	}
}