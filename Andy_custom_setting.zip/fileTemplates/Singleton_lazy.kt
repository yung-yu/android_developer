package ${PACKAGE_NAME};

#parse("File Header.java")
class ${NAME}{
    companion object {
     const val TAG = "${NAME}"
     val instance: ${NAME} by lazy {
         ${NAME}()
     }
   }
}