package ${PACKAGE_NAME}

import android.app.Activity
import android.os.Bundle

#parse("File Header.java")
class ${NAME} : Activity(){
   companion object {
     const val TAG = "${NAME}"
   }
   
   override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		Log.i(TAG, "onCreate")
	}

	override fun onStart() {
		super.onStart()
		Log.i(TAG, "onStart")
	}


	override fun onResume() {
		super.onResume()
		Log.d(TAG, "onResume")

	}

	override fun onPause() {
		super.onPause()
		Log.d(TAG, "onPause")

	}

	override fun onStop() {
		super.onStop()
		Log.d(TAG, "onStop")

	}

	override fun onDestroy() {
		super.onDestroy()
		Log.d(TAG, "onDestroy")
	}
}